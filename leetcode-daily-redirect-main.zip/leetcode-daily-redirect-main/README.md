# leetcode-daily-redirect

Redirect to LeetCode Daily Problem.
